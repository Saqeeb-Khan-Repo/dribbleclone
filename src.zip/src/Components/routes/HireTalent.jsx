import Talent from '../Pages/Talent/Talent'

const HireTalent = () => {
  return (
    <div>
      <Talent/>
    </div>
  )
}

export default HireTalent
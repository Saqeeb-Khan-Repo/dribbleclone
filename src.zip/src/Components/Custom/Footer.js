export const listItem = ["For Designers","Hire Talent","Inspiration","Advertising","Blog","About","Careers","Support"]
